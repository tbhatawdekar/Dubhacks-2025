import styles from "../styles/about.module.css";

export default function about() {
  return (
    <main className={styles.main}>
      <p>This is the about/learn more page</p>
    </main>
  );
}
