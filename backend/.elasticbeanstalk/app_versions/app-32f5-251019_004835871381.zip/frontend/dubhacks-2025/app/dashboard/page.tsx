import styles from "../styles/dashboard.module.css";

export default function dashboard() {
  return (
    <main className={styles.main}>
      <p>This is the dashboard</p>
    </main>
  );
}
